import pyvisa

__all__ = ('rm',)

ResourceManager = pyvisa.ResourceManager